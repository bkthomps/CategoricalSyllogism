Bailey Thompson
Categorical Syllogism (1.0.4)
16 January 2016

Randomly generates a categorical syllogism and the three letters and one number which describes it. It also
states whether the syllogism is valid or invalid. As such, if a fallacy is committed, the fallacy will be red,
if the fallacy is not committed, it will be green. It is also possible to add words which will be randomly
generated in the statements. Last but not least, the program has a venn diagram. Check marks will appear as
green, x marks will appear as red, and filled in sections will be filled in with orange.


If you do not have the Java 8 JRE, please follow these steps.
1. Go to this website: http://www.oracle.com/technetwork/java/javase/downloads/jre8-downloads-2133155.html
2. Accept the license agreement
3. Download the version that best suits your operating system
4. Wait for the download to be completed
5. Start the .jar file in the folder in which you found these instructions